# Map menu buttons set this trigger; teleport whoever pressed one.
scoreboard players enable @a dl_go
execute as @a[scores={dl_go=1..}] at @s run function dl:menu_choice
