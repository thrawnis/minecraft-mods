# Teleport yourself to the Galaxy's Edge station.
execute unless data storage dl:stations galaxys_edge run return run tellraw @s {"text":"That station is not built yet.","color":"red"}
function dl:tp with storage dl:stations galaxys_edge
tellraw @s {"text":"Welcome to Galaxy's Edge!","color":"gold"}
