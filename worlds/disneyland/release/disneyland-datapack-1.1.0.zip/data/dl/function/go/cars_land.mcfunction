# Teleport yourself to the Cars Land station.
execute unless data storage dl:stations cars_land run return run tellraw @s {"text":"That station is not built yet.","color":"red"}
function dl:tp with storage dl:stations cars_land
tellraw @s {"text":"Welcome to Cars Land!","color":"gold"}
