# Teleport yourself to the New Orleans Square station.
execute unless data storage dl:stations new_orleans run return run tellraw @s {"text":"That station is not built yet.","color":"red"}
function dl:tp with storage dl:stations new_orleans
tellraw @s {"text":"Welcome to New Orleans Square!","color":"gold"}
