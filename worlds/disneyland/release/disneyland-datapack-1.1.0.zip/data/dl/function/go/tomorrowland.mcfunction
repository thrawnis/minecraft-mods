# Teleport yourself to the Tomorrowland station.
execute unless data storage dl:stations tomorrowland run return run tellraw @s {"text":"That station is not built yet.","color":"red"}
function dl:tp with storage dl:stations tomorrowland
tellraw @s {"text":"Welcome to Tomorrowland!","color":"gold"}
