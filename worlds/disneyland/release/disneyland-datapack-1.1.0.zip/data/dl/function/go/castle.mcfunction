# Teleport yourself to the Sleeping Beauty Castle station.
execute unless data storage dl:stations castle run return run tellraw @s {"text":"That station is not built yet.","color":"red"}
function dl:tp with storage dl:stations castle
tellraw @s {"text":"Welcome to Sleeping Beauty Castle!","color":"gold"}
