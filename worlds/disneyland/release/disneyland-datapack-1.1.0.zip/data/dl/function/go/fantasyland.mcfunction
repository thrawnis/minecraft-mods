# Teleport yourself to the Fantasyland station.
execute unless data storage dl:stations fantasyland run return run tellraw @s {"text":"That station is not built yet.","color":"red"}
function dl:tp with storage dl:stations fantasyland
tellraw @s {"text":"Welcome to Fantasyland!","color":"gold"}
