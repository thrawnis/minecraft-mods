# Teleport yourself to the Disneyland Hotel station.
execute unless data storage dl:stations hotel run return run tellraw @s {"text":"That station is not built yet.","color":"red"}
function dl:tp with storage dl:stations hotel
tellraw @s {"text":"Welcome to Disneyland Hotel!","color":"gold"}
