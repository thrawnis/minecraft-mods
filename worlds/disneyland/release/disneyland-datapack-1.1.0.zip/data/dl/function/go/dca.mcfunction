# Teleport yourself to the California Adventure station.
execute unless data storage dl:stations dca run return run tellraw @s {"text":"That station is not built yet.","color":"red"}
function dl:tp with storage dl:stations dca
tellraw @s {"text":"Welcome to California Adventure!","color":"gold"}
