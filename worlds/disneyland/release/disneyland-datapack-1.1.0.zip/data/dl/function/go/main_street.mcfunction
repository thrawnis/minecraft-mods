# Teleport yourself to the Main Street, U.S.A. station.
execute unless data storage dl:stations main_street run return run tellraw @s {"text":"That station is not built yet.","color":"red"}
function dl:tp with storage dl:stations main_street
tellraw @s {"text":"Welcome to Main Street, U.S.A.!","color":"gold"}
