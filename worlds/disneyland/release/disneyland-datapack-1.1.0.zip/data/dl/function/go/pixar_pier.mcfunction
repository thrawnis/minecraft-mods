# Teleport yourself to the Pixar Pier station.
execute unless data storage dl:stations pixar_pier run return run tellraw @s {"text":"That station is not built yet.","color":"red"}
function dl:tp with storage dl:stations pixar_pier
tellraw @s {"text":"Welcome to Pixar Pier!","color":"gold"}
