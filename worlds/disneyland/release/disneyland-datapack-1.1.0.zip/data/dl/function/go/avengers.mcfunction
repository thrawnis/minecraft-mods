# Teleport yourself to the Avengers Campus station.
execute unless data storage dl:stations avengers run return run tellraw @s {"text":"That station is not built yet.","color":"red"}
function dl:tp with storage dl:stations avengers
tellraw @s {"text":"Welcome to Avengers Campus!","color":"gold"}
