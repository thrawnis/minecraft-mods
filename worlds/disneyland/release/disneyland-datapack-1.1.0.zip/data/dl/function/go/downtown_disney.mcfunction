# Teleport yourself to the Downtown Disney station.
execute unless data storage dl:stations downtown_disney run return run tellraw @s {"text":"That station is not built yet.","color":"red"}
function dl:tp with storage dl:stations downtown_disney
tellraw @s {"text":"Welcome to Downtown Disney!","color":"gold"}
