# Standing here: ground underfoot, and solid below it (a roof has rooms or air under it).
execute unless block ~ ~-1 ~ #dl:ground run return fail
execute if block ~ ~-3 ~ #dl:hollow run return fail
execute if block ~ ~-4 ~ #dl:hollow run return fail
# Not the top of a wall or ledge: no drop of more than 3 blocks right next to it.
execute if block ~1 ~-4 ~ #dl:hollow run return fail
execute if block ~-1 ~-4 ~ #dl:hollow run return fail
execute if block ~ ~-4 ~1 #dl:hollow run return fail
execute if block ~ ~-4 ~-1 #dl:hollow run return fail
return 1
