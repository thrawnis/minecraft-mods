# Avengers Campus station, built here (standing level).
summon marker ~ ~ ~1 {Tags:["dl_tmp"]}
execute as @e[type=marker,tag=dl_tmp,limit=1] run function dl:store/avengers
kill @e[type=marker,tag=dl_tmp]
function dl:station/structure
setblock ~ ~2 ~-1 oak_wall_sign[facing=south]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Station","Avengers Campus","Press button","for map menu"]}}
