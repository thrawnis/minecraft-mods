# Tour sign: Disneyland / Railroad / Since 1955
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Disneyland","Railroad","Since 1955",""]},back_text:{has_glowing_text:1b,messages:["Disneyland","Railroad","Since 1955",""]}}
