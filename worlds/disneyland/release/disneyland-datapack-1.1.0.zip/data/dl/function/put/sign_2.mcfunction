# Tour sign: Sleeping Beauty / Castle / Opened 1955 / 23 m tall
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Sleeping Beauty","Castle","Opened 1955","23 m tall"]},back_text:{has_glowing_text:1b,messages:["Sleeping Beauty","Castle","Opened 1955","23 m tall"]}}
