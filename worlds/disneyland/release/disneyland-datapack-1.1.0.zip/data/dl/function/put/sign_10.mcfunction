# Tour sign: Pixar Pier / Opened 2018
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Pixar Pier","Opened 2018","",""]},back_text:{has_glowing_text:1b,messages:["Pixar Pier","Opened 2018","",""]}}
