# Cars Land station, built here (standing level).
summon marker ~ ~ ~1 {Tags:["dl_tmp"]}
execute as @e[type=marker,tag=dl_tmp,limit=1] run function dl:store/cars_land
kill @e[type=marker,tag=dl_tmp]
function dl:station/structure
setblock ~ ~2 ~-1 oak_wall_sign[facing=south]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Station","Cars Land","Press button","for map menu"]}}
