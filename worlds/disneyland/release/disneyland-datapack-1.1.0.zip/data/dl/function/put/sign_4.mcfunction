# Tour sign: Pirates of the / Caribbean / Opened 1967
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Pirates of the","Caribbean","Opened 1967",""]},back_text:{has_glowing_text:1b,messages:["Pirates of the","Caribbean","Opened 1967",""]}}
