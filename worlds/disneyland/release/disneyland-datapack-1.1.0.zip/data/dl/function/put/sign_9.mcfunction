# Tour sign: Cars Land / Opened 2012
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Cars Land","Opened 2012","",""]},back_text:{has_glowing_text:1b,messages:["Cars Land","Opened 2012","",""]}}
