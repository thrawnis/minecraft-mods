# Tour sign: Star Wars: / Galaxy's Edge / Opened 2019
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Star Wars:","Galaxy's Edge","Opened 2019",""]},back_text:{has_glowing_text:1b,messages:["Star Wars:","Galaxy's Edge","Opened 2019",""]}}
