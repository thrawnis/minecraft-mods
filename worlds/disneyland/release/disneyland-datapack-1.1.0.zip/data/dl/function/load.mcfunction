scoreboard objectives add dl dummy
scoreboard objectives add dl_go trigger
scoreboard players set #16 dl 16
execute unless data storage dl:state {built:1b} run function dl:setup
