execute store result storage dl:stations pixar_pier.x double 0.5 run data get entity @s Pos[0] 2
execute store result storage dl:stations pixar_pier.y double 0.5 run data get entity @s Pos[1] 2
execute store result storage dl:stations pixar_pier.z double 0.5 run data get entity @s Pos[2] 2
