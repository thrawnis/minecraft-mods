execute store result storage dl:stations new_orleans.x double 0.5 run data get entity @s Pos[0] 2
execute store result storage dl:stations new_orleans.y double 0.5 run data get entity @s Pos[1] 2
execute store result storage dl:stations new_orleans.z double 0.5 run data get entity @s Pos[2] 2
