execute store result storage dl:stations castle.x double 0.5 run data get entity @s Pos[0] 2
execute store result storage dl:stations castle.y double 0.5 run data get entity @s Pos[1] 2
execute store result storage dl:stations castle.z double 0.5 run data get entity @s Pos[2] 2
