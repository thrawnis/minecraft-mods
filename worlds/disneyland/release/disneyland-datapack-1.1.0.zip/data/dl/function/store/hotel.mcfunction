execute store result storage dl:stations hotel.x double 0.5 run data get entity @s Pos[0] 2
execute store result storage dl:stations hotel.y double 0.5 run data get entity @s Pos[1] 2
execute store result storage dl:stations hotel.z double 0.5 run data get entity @s Pos[2] 2
