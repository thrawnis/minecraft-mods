execute store result storage dl:stations galaxys_edge.x double 0.5 run data get entity @s Pos[0] 2
execute store result storage dl:stations galaxys_edge.y double 0.5 run data get entity @s Pos[1] 2
execute store result storage dl:stations galaxys_edge.z double 0.5 run data get entity @s Pos[2] 2
