execute store result storage dl:stations main_street.x double 0.5 run data get entity @s Pos[0] 2
execute store result storage dl:stations main_street.y double 0.5 run data get entity @s Pos[1] 2
execute store result storage dl:stations main_street.z double 0.5 run data get entity @s Pos[2] 2
