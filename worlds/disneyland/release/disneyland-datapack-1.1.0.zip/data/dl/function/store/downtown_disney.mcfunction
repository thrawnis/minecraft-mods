execute store result storage dl:stations downtown_disney.x double 0.5 run data get entity @s Pos[0] 2
execute store result storage dl:stations downtown_disney.y double 0.5 run data get entity @s Pos[1] 2
execute store result storage dl:stations downtown_disney.z double 0.5 run data get entity @s Pos[2] 2
