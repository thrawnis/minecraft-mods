# Rebuild the Avengers Campus station where you are standing.
execute align xz positioned ~0.5 ~ ~0.5 run function dl:put/station_avengers
tellraw @s {"text":"Avengers Campus station moved here.","color":"green"}
