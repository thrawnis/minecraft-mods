# Rebuild the Disneyland Hotel station where you are standing.
execute align xz positioned ~0.5 ~ ~0.5 run function dl:put/station_hotel
tellraw @s {"text":"Disneyland Hotel station moved here.","color":"green"}
