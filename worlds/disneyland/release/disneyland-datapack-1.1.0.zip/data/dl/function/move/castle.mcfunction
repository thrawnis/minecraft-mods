# Rebuild the Sleeping Beauty Castle station where you are standing.
execute align xz positioned ~0.5 ~ ~0.5 run function dl:put/station_castle
tellraw @s {"text":"Sleeping Beauty Castle station moved here.","color":"green"}
