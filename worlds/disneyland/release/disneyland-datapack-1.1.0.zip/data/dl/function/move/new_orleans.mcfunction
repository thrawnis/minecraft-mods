# Rebuild the New Orleans Square station where you are standing.
execute align xz positioned ~0.5 ~ ~0.5 run function dl:put/station_new_orleans
tellraw @s {"text":"New Orleans Square station moved here.","color":"green"}
