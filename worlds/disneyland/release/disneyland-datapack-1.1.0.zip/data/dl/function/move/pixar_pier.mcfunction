# Rebuild the Pixar Pier station where you are standing.
execute align xz positioned ~0.5 ~ ~0.5 run function dl:put/station_pixar_pier
tellraw @s {"text":"Pixar Pier station moved here.","color":"green"}
