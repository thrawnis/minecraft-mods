# Rebuild the Tomorrowland station where you are standing.
execute align xz positioned ~0.5 ~ ~0.5 run function dl:put/station_tomorrowland
tellraw @s {"text":"Tomorrowland station moved here.","color":"green"}
