# Rebuild the California Adventure station where you are standing.
execute align xz positioned ~0.5 ~ ~0.5 run function dl:put/station_dca
tellraw @s {"text":"California Adventure station moved here.","color":"green"}
