# Rebuild the Cars Land station where you are standing.
execute align xz positioned ~0.5 ~ ~0.5 run function dl:put/station_cars_land
tellraw @s {"text":"Cars Land station moved here.","color":"green"}
