# Rebuild the Galaxy's Edge station where you are standing.
execute align xz positioned ~0.5 ~ ~0.5 run function dl:put/station_galaxys_edge
tellraw @s {"text":"Galaxy's Edge station moved here.","color":"green"}
