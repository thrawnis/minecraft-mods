# Rebuild the Main Street, U.S.A. station where you are standing.
execute align xz positioned ~0.5 ~ ~0.5 run function dl:put/station_main_street
tellraw @s {"text":"Main Street, U.S.A. station moved here.","color":"green"}
