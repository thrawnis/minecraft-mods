# Rebuild the Downtown Disney station where you are standing.
execute align xz positioned ~0.5 ~ ~0.5 run function dl:put/station_downtown_disney
tellraw @s {"text":"Downtown Disney station moved here.","color":"green"}
