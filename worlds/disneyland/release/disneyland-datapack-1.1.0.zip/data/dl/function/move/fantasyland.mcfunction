# Rebuild the Fantasyland station where you are standing.
execute align xz positioned ~0.5 ~ ~0.5 run function dl:put/station_fantasyland
tellraw @s {"text":"Fantasyland station moved here.","color":"green"}
