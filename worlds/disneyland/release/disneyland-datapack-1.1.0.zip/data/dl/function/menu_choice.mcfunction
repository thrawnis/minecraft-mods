execute if score @s dl_go matches 1 run function dl:go/main_street
execute if score @s dl_go matches 2 run function dl:go/castle
execute if score @s dl_go matches 3 run function dl:go/fantasyland
execute if score @s dl_go matches 4 run function dl:go/tomorrowland
execute if score @s dl_go matches 5 run function dl:go/new_orleans
execute if score @s dl_go matches 6 run function dl:go/galaxys_edge
execute if score @s dl_go matches 7 run function dl:go/dca
execute if score @s dl_go matches 8 run function dl:go/cars_land
execute if score @s dl_go matches 9 run function dl:go/pixar_pier
execute if score @s dl_go matches 10 run function dl:go/avengers
execute if score @s dl_go matches 11 run function dl:go/downtown_disney
execute if score @s dl_go matches 12 run function dl:go/hotel
scoreboard players set @s dl_go 0
