dialog show @s dl:menu
