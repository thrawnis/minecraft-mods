scoreboard objectives add lanyc dummy
scoreboard objectives add lanyc_go trigger
scoreboard players set #16 lanyc 16
execute unless data storage lanyc:state {built:1b} run function lanyc:setup
# Version 2.0.0 had a night-lights loop; make sure it's stopped in worlds upgraded from it.
schedule clear lanyc:lamps/loop
