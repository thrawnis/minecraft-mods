execute store result storage lanyc:stations empire_state.x double 0.5 run data get entity @s Pos[0] 2
execute store result storage lanyc:stations empire_state.y double 0.5 run data get entity @s Pos[1] 2
execute store result storage lanyc:stations empire_state.z double 0.5 run data get entity @s Pos[2] 2
