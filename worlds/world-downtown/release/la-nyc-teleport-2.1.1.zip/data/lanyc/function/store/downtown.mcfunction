execute store result storage lanyc:stations downtown.x double 0.5 run data get entity @s Pos[0] 2
execute store result storage lanyc:stations downtown.y double 0.5 run data get entity @s Pos[1] 2
execute store result storage lanyc:stations downtown.z double 0.5 run data get entity @s Pos[2] 2
