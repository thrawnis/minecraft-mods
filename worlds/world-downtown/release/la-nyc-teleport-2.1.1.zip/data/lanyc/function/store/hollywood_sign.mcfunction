execute store result storage lanyc:stations hollywood_sign.x double 0.5 run data get entity @s Pos[0] 2
execute store result storage lanyc:stations hollywood_sign.y double 0.5 run data get entity @s Pos[1] 2
execute store result storage lanyc:stations hollywood_sign.z double 0.5 run data get entity @s Pos[2] 2
