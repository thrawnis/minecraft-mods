execute store result storage lanyc:stations hollywood.x double 0.5 run data get entity @s Pos[0] 2
execute store result storage lanyc:stations hollywood.y double 0.5 run data get entity @s Pos[1] 2
execute store result storage lanyc:stations hollywood.z double 0.5 run data get entity @s Pos[2] 2
