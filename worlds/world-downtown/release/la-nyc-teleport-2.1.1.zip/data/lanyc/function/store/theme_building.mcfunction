execute store result storage lanyc:stations theme_building.x double 0.5 run data get entity @s Pos[0] 2
execute store result storage lanyc:stations theme_building.y double 0.5 run data get entity @s Pos[1] 2
execute store result storage lanyc:stations theme_building.z double 0.5 run data get entity @s Pos[2] 2
