# Teleport yourself to the LAX Terminals station.
execute unless data storage lanyc:stations lax run return run tellraw @s {"text":"That station is not built yet.","color":"red"}
function lanyc:tp with storage lanyc:stations lax
tellraw @s {"text":"Welcome to LAX Terminals!","color":"gold"}
