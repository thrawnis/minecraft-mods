# Teleport yourself to the Hollywood station.
execute unless data storage lanyc:stations hollywood run return run tellraw @s {"text":"That station is not built yet.","color":"red"}
function lanyc:tp with storage lanyc:stations hollywood
tellraw @s {"text":"Welcome to Hollywood!","color":"gold"}
