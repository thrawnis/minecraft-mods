# Teleport yourself to the Downtown LA station.
execute unless data storage lanyc:stations downtown run return run tellraw @s {"text":"That station is not built yet.","color":"red"}
function lanyc:tp with storage lanyc:stations downtown
tellraw @s {"text":"Welcome to Downtown LA!","color":"gold"}
