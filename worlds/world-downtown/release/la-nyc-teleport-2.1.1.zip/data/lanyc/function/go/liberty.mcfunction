# Teleport yourself to the Statue of Liberty station.
execute unless data storage lanyc:stations liberty run return run tellraw @s {"text":"That station is not built yet.","color":"red"}
function lanyc:tp with storage lanyc:stations liberty
tellraw @s {"text":"Welcome to Statue of Liberty!","color":"gold"}
