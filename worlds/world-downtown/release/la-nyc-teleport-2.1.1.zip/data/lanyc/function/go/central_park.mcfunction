# Teleport yourself to the Central Park station.
execute unless data storage lanyc:stations central_park run return run tellraw @s {"text":"That station is not built yet.","color":"red"}
function lanyc:tp with storage lanyc:stations central_park
tellraw @s {"text":"Welcome to Central Park!","color":"gold"}
