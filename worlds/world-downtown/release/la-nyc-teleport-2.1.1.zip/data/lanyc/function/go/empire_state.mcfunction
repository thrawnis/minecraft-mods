# Teleport yourself to the Empire State roof station.
execute unless data storage lanyc:stations empire_state run return run tellraw @s {"text":"That station is not built yet.","color":"red"}
function lanyc:tp with storage lanyc:stations empire_state
tellraw @s {"text":"Welcome to Empire State roof!","color":"gold"}
