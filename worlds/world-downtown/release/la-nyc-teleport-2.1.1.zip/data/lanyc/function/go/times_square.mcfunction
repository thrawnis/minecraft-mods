# Teleport yourself to the Times Square station.
execute unless data storage lanyc:stations times_square run return run tellraw @s {"text":"That station is not built yet.","color":"red"}
function lanyc:tp with storage lanyc:stations times_square
tellraw @s {"text":"Welcome to Times Square!","color":"gold"}
