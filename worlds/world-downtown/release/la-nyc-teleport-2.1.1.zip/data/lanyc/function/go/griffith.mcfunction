# Teleport yourself to the Griffith Observatory station.
execute unless data storage lanyc:stations griffith run return run tellraw @s {"text":"That station is not built yet.","color":"red"}
function lanyc:tp with storage lanyc:stations griffith
tellraw @s {"text":"Welcome to Griffith Observatory!","color":"gold"}
