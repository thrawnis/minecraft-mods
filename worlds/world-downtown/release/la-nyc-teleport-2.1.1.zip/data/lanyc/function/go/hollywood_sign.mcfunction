# Teleport yourself to the Hollywood Sign station.
execute unless data storage lanyc:stations hollywood_sign run return run tellraw @s {"text":"That station is not built yet.","color":"red"}
function lanyc:tp with storage lanyc:stations hollywood_sign
tellraw @s {"text":"Welcome to Hollywood Sign!","color":"gold"}
