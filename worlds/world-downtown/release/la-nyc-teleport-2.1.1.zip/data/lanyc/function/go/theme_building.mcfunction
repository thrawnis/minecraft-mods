# Teleport yourself to the LAX Theme Building station.
execute unless data storage lanyc:stations theme_building run return run tellraw @s {"text":"That station is not built yet.","color":"red"}
function lanyc:tp with storage lanyc:stations theme_building
tellraw @s {"text":"Welcome to LAX Theme Building!","color":"gold"}
