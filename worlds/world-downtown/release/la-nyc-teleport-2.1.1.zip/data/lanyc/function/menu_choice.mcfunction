execute if score @s lanyc_go matches 1 run function lanyc:go/hollywood
execute if score @s lanyc_go matches 2 run function lanyc:go/hollywood_sign
execute if score @s lanyc_go matches 3 run function lanyc:go/griffith
execute if score @s lanyc_go matches 4 run function lanyc:go/downtown
execute if score @s lanyc_go matches 5 run function lanyc:go/lax
execute if score @s lanyc_go matches 6 run function lanyc:go/theme_building
execute if score @s lanyc_go matches 7 run function lanyc:go/times_square
execute if score @s lanyc_go matches 8 run function lanyc:go/empire_state
execute if score @s lanyc_go matches 9 run function lanyc:go/central_park
execute if score @s lanyc_go matches 10 run function lanyc:go/liberty
scoreboard players set @s lanyc_go 0
