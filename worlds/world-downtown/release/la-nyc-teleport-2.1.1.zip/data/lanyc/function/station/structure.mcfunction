# Platform, a short wall with one button that opens the map menu. You stand 2 in front.
fill ~-2 ~ ~-3 ~2 ~4 ~2 air
fill ~-2 ~-1 ~-3 ~2 ~-1 ~2 smooth_stone
fill ~-1 ~ ~-2 ~1 ~2 ~-2 smooth_stone
setblock ~-1 ~2 ~-2 sea_lantern
setblock ~1 ~2 ~-2 sea_lantern
setblock ~ ~1 ~-2 command_block[facing=up]{Command:"execute as @p run function lanyc:menu"}
setblock ~ ~1 ~-1 stone_button[face=wall,facing=south]
