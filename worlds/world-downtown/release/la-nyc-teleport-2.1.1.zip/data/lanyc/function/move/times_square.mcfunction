# Rebuild the Times Square station where you are standing.
execute align xz positioned ~0.5 ~ ~0.5 run function lanyc:put/station_times_square
tellraw @s {"text":"Times Square station moved here.","color":"green"}
