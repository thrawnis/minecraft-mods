# Rebuild the Hollywood Sign station where you are standing.
execute align xz positioned ~0.5 ~ ~0.5 run function lanyc:put/station_hollywood_sign
tellraw @s {"text":"Hollywood Sign station moved here.","color":"green"}
