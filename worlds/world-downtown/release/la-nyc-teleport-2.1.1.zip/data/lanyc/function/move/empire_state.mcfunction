# Rebuild the Empire State roof station where you are standing.
execute align xz positioned ~0.5 ~ ~0.5 run function lanyc:put/station_empire_state
tellraw @s {"text":"Empire State roof station moved here.","color":"green"}
