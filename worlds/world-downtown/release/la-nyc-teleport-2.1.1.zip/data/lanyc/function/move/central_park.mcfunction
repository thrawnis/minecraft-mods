# Rebuild the Central Park station where you are standing.
execute align xz positioned ~0.5 ~ ~0.5 run function lanyc:put/station_central_park
tellraw @s {"text":"Central Park station moved here.","color":"green"}
