# Rebuild the LAX Theme Building station where you are standing.
execute align xz positioned ~0.5 ~ ~0.5 run function lanyc:put/station_theme_building
tellraw @s {"text":"LAX Theme Building station moved here.","color":"green"}
