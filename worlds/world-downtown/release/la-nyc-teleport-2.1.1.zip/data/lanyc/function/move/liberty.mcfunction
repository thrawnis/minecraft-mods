# Rebuild the Statue of Liberty station where you are standing.
execute align xz positioned ~0.5 ~ ~0.5 run function lanyc:put/station_liberty
tellraw @s {"text":"Statue of Liberty station moved here.","color":"green"}
