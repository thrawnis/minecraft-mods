# Rebuild the Griffith Observatory station where you are standing.
execute align xz positioned ~0.5 ~ ~0.5 run function lanyc:put/station_griffith
tellraw @s {"text":"Griffith Observatory station moved here.","color":"green"}
