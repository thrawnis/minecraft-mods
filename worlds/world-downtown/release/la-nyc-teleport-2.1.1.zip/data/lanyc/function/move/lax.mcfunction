# Rebuild the LAX Terminals station where you are standing.
execute align xz positioned ~0.5 ~ ~0.5 run function lanyc:put/station_lax
tellraw @s {"text":"LAX Terminals station moved here.","color":"green"}
