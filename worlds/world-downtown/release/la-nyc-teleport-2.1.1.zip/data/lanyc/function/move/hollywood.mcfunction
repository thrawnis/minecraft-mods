# Rebuild the Hollywood station where you are standing.
execute align xz positioned ~0.5 ~ ~0.5 run function lanyc:put/station_hollywood
tellraw @s {"text":"Hollywood station moved here.","color":"green"}
