# Rebuild the Downtown LA station where you are standing.
execute align xz positioned ~0.5 ~ ~0.5 run function lanyc:put/station_downtown
tellraw @s {"text":"Downtown LA station moved here.","color":"green"}
