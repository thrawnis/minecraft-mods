# Tour sign: Wilshire Grand / Center / 335 m (spire) / Opened 2017
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Wilshire Grand","Center","335 m (spire)","Opened 2017"]},back_text:{has_glowing_text:1b,messages:["Wilshire Grand","Center","335 m (spire)","Opened 2017"]}}
