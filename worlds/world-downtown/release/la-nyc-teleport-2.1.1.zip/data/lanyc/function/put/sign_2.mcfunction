# Tour sign: Hollywood Walk / of Fame / 2,700+ stars / since 1960
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Hollywood Walk","of Fame","2,700+ stars","since 1960"]},back_text:{has_glowing_text:1b,messages:["Hollywood Walk","of Fame","2,700+ stars","since 1960"]}}
