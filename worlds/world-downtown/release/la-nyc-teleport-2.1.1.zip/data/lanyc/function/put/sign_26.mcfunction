# Tour sign: Bow Bridge / Built 1862 / Cast iron
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Bow Bridge","Built 1862","Cast iron",""]},back_text:{has_glowing_text:1b,messages:["Bow Bridge","Built 1862","Cast iron",""]}}
