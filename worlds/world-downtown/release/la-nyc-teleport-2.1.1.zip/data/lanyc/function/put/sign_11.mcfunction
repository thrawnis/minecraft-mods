# Tour sign: Grand Central / Market / Open since 1917
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Grand Central","Market","Open since 1917",""]},back_text:{has_glowing_text:1b,messages:["Grand Central","Market","Open since 1917",""]}}
