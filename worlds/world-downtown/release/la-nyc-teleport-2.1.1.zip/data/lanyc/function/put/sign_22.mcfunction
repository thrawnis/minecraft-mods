# Tour sign: Chrysler / Building / Opened 1930 / 319 m tall
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Chrysler","Building","Opened 1930","319 m tall"]},back_text:{has_glowing_text:1b,messages:["Chrysler","Building","Opened 1930","319 m tall"]}}
