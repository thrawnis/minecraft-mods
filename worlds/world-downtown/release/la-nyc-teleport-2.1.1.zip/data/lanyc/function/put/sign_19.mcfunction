# Tour sign: Grand Central / Terminal / Opened 1913 / 44 platforms
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Grand Central","Terminal","Opened 1913","44 platforms"]},back_text:{has_glowing_text:1b,messages:["Grand Central","Terminal","Opened 1913","44 platforms"]}}
