# Tour sign: Jacqueline / Kennedy Onassis / Reservoir
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Jacqueline","Kennedy Onassis","Reservoir",""]},back_text:{has_glowing_text:1b,messages:["Jacqueline","Kennedy Onassis","Reservoir",""]}}
