# Tour sign: Hollywood Sign / Built 1923 as / HOLLYWOODLAND / Letters 14 m
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Hollywood Sign","Built 1923 as","HOLLYWOODLAND","Letters 14 m"]},back_text:{has_glowing_text:1b,messages:["Hollywood Sign","Built 1923 as","HOLLYWOODLAND","Letters 14 m"]}}
