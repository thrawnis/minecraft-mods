# Tour sign: Central Park / Opened 1858 / 843 acres
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Central Park","Opened 1858","843 acres",""]},back_text:{has_glowing_text:1b,messages:["Central Park","Opened 1858","843 acres",""]}}
