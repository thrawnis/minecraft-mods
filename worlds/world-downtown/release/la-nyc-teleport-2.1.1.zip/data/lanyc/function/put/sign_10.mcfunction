# Tour sign: Los Angeles / City Hall / Built 1928 / 138 m tall
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Los Angeles","City Hall","Built 1928","138 m tall"]},back_text:{has_glowing_text:1b,messages:["Los Angeles","City Hall","Built 1928","138 m tall"]}}
