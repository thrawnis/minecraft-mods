# Empire State roof station, built here (standing level).
summon marker ~ ~ ~1 {Tags:["lanyc_tmp"]}
execute as @e[type=marker,tag=lanyc_tmp,limit=1] run function lanyc:store/empire_state
kill @e[type=marker,tag=lanyc_tmp]
function lanyc:station/structure
setblock ~ ~2 ~-1 oak_wall_sign[facing=south]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Station","Empire State roof","Press button","for map menu"]}}
