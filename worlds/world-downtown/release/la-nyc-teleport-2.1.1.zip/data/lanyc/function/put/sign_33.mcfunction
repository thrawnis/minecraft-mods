# Tour sign: Ellis Island / Immigration / station / 1892-1954
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Ellis Island","Immigration","station","1892-1954"]},back_text:{has_glowing_text:1b,messages:["Ellis Island","Immigration","station","1892-1954"]}}
