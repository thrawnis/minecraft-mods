# Tour sign: TCL Chinese / Theatre / Opened 1927 / Star handprints
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["TCL Chinese","Theatre","Opened 1927","Star handprints"]},back_text:{has_glowing_text:1b,messages:["TCL Chinese","Theatre","Opened 1927","Star handprints"]}}
