# Tour sign: The Met / Museum of Art / Founded 1870
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["The Met","Museum of Art","Founded 1870",""]},back_text:{has_glowing_text:1b,messages:["The Met","Museum of Art","Founded 1870",""]}}
