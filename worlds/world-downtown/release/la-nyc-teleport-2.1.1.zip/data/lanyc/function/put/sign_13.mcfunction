# Tour sign: Theme Building / Opened 1961 / Space Age / landmark
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Theme Building","Opened 1961","Space Age","landmark"]},back_text:{has_glowing_text:1b,messages:["Theme Building","Opened 1961","Space Age","landmark"]}}
