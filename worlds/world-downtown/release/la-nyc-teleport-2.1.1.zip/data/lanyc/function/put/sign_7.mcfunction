# Tour sign: Walt Disney / Concert Hall / Frank Gehry / Opened 2003
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Walt Disney","Concert Hall","Frank Gehry","Opened 2003"]},back_text:{has_glowing_text:1b,messages:["Walt Disney","Concert Hall","Frank Gehry","Opened 2003"]}}
