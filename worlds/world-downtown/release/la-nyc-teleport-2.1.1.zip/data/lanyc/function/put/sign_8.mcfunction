# Tour sign: U.S. Bank Tower / 310 m tall / Completed 1989
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["U.S. Bank Tower","310 m tall","Completed 1989",""]},back_text:{has_glowing_text:1b,messages:["U.S. Bank Tower","310 m tall","Completed 1989",""]}}
