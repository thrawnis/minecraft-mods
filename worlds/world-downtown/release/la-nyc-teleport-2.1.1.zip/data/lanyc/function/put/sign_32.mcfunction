# Tour sign: Statue of / Liberty / Gift of France / Dedicated 1886
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Statue of","Liberty","Gift of France","Dedicated 1886"]},back_text:{has_glowing_text:1b,messages:["Statue of","Liberty","Gift of France","Dedicated 1886"]}}
