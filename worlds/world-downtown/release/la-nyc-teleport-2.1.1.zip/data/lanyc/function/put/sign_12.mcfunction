# Tour sign: Crypto.com / Arena / Opened 1999 / Home of Lakers
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Crypto.com","Arena","Opened 1999","Home of Lakers"]},back_text:{has_glowing_text:1b,messages:["Crypto.com","Arena","Opened 1999","Home of Lakers"]}}
