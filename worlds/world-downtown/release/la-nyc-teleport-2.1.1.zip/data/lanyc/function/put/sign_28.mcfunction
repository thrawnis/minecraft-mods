# Tour sign: Strawberry / Fields / John Lennon / memorial
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Strawberry","Fields","John Lennon","memorial"]},back_text:{has_glowing_text:1b,messages:["Strawberry","Fields","John Lennon","memorial"]}}
