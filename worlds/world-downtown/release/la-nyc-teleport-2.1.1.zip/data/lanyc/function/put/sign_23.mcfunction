# Tour sign: Madison Square / Garden / Opened 1968
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Madison Square","Garden","Opened 1968",""]},back_text:{has_glowing_text:1b,messages:["Madison Square","Garden","Opened 1968",""]}}
