# Tour sign: Capitol Records / Opened 1956 / Shaped like a / stack of discs
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Capitol Records","Opened 1956","Shaped like a","stack of discs"]},back_text:{has_glowing_text:1b,messages:["Capitol Records","Opened 1956","Shaped like a","stack of discs"]}}
