# Tour sign: Los Angeles / Intl Airport / (LAX) / Opened 1928
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Los Angeles","Intl Airport","(LAX)","Opened 1928"]},back_text:{has_glowing_text:1b,messages:["Los Angeles","Intl Airport","(LAX)","Opened 1928"]}}
