# Tour sign: Rockefeller / Center / 30 Rock opened / 1933
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Rockefeller","Center","30 Rock opened","1933"]},back_text:{has_glowing_text:1b,messages:["Rockefeller","Center","30 Rock opened","1933"]}}
