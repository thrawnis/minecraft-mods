# Tour sign: Hollywood Bowl / Opened 1922 / Outdoor concert / amphitheatre
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Hollywood Bowl","Opened 1922","Outdoor concert","amphitheatre"]},back_text:{has_glowing_text:1b,messages:["Hollywood Bowl","Opened 1922","Outdoor concert","amphitheatre"]}}
