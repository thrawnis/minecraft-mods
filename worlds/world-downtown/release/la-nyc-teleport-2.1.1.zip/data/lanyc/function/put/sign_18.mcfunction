# Tour sign: NY Public / Library / Opened 1911 / Lions guard it
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["NY Public","Library","Opened 1911","Lions guard it"]},back_text:{has_glowing_text:1b,messages:["NY Public","Library","Opened 1911","Lions guard it"]}}
