# Tour sign: Times Square / Named 1904 / New Year's ball / drop since 1907
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Times Square","Named 1904","New Year's ball","drop since 1907"]},back_text:{has_glowing_text:1b,messages:["Times Square","Named 1904","New Year's ball","drop since 1907"]}}
