# Tour sign: Dolby Theatre / Home of the / Oscars since / 2002
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Dolby Theatre","Home of the","Oscars since","2002"]},back_text:{has_glowing_text:1b,messages:["Dolby Theatre","Home of the","Oscars since","2002"]}}
