# Tour sign: Griffith / Observatory / Opened 1935 / Free admission
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Griffith","Observatory","Opened 1935","Free admission"]},back_text:{has_glowing_text:1b,messages:["Griffith","Observatory","Opened 1935","Free admission"]}}
