# Map menu buttons set this trigger; teleport whoever pressed one.
scoreboard players enable @a lanyc_go
execute as @a[scores={lanyc_go=1..}] at @s run function lanyc:menu_choice
