dialog show @s lanyc:menu
