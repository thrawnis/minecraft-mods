$function lanyc:put/$(id)
