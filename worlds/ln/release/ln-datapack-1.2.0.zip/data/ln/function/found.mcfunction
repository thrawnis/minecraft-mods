$function ln:put/$(id)
