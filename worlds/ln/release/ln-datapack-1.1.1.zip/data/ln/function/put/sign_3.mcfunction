# Tour sign: Laguna Niguel / / Mission Viejo / Metrolink / station
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Laguna Niguel /","Mission Viejo","Metrolink","station"]},back_text:{has_glowing_text:1b,messages:["Laguna Niguel /","Mission Viejo","Metrolink","station"]}}
