# Metrolink station station, built here (standing level).
summon marker ~ ~ ~1 {Tags:["ln_tmp"]}
execute as @e[type=marker,tag=ln_tmp,limit=1] run function ln:store/metrolink
kill @e[type=marker,tag=ln_tmp]
function ln:station/structure
setblock ~ ~2 ~-1 oak_wall_sign[facing=south]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Station","Metrolink station","Press button","for map menu"]}}
