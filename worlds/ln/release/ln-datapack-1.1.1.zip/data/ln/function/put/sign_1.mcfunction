# Tour sign: Laguna Niguel / Regional Park / Lake & trails
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Laguna Niguel","Regional Park","Lake & trails",""]},back_text:{has_glowing_text:1b,messages:["Laguna Niguel","Regional Park","Lake & trails",""]}}
