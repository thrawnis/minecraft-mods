# Regional Park station, built here (standing level).
summon marker ~ ~ ~1 {Tags:["ln_tmp"]}
execute as @e[type=marker,tag=ln_tmp,limit=1] run function ln:store/regional_park
kill @e[type=marker,tag=ln_tmp]
function ln:station/structure
setblock ~ ~2 ~-1 oak_wall_sign[facing=south]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Station","Regional Park","Press button","for map menu"]}}
