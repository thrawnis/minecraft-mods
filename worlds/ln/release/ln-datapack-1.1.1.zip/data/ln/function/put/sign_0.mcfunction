# Tour sign: Laguna Niguel / City Hall / City since / 1989
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["Laguna Niguel","City Hall","City since","1989"]},back_text:{has_glowing_text:1b,messages:["Laguna Niguel","City Hall","City since","1989"]}}
