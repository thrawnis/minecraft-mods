# Tour sign: The Ziggurat / Chet Holifield / Federal Bldg / Built 1971
setblock ~ ~ ~ stone_brick_wall
setblock ~ ~1 ~ oak_sign[rotation=0]{is_waxed:1b,front_text:{has_glowing_text:1b,messages:["The Ziggurat","Chet Holifield","Federal Bldg","Built 1971"]},back_text:{has_glowing_text:1b,messages:["The Ziggurat","Chet Holifield","Federal Bldg","Built 1971"]}}
