execute store result storage ln:stations regional_park.x double 0.5 run data get entity @s Pos[0] 2
execute store result storage ln:stations regional_park.y double 0.5 run data get entity @s Pos[1] 2
execute store result storage ln:stations regional_park.z double 0.5 run data get entity @s Pos[2] 2
