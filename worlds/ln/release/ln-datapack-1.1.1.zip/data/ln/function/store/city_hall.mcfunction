execute store result storage ln:stations city_hall.x double 0.5 run data get entity @s Pos[0] 2
execute store result storage ln:stations city_hall.y double 0.5 run data get entity @s Pos[1] 2
execute store result storage ln:stations city_hall.z double 0.5 run data get entity @s Pos[2] 2
