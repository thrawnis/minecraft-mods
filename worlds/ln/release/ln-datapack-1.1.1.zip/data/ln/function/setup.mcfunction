# Load each station's and sign's chunk while they are built.
forceload add -140 -78
forceload add -158 -56
forceload add -612 -3682
forceload add -631 -3648
forceload add 139 -1669
forceload add 157 -1702
forceload add 2873 -4104
forceload add 2892 -4138
schedule function ln:build 20t
