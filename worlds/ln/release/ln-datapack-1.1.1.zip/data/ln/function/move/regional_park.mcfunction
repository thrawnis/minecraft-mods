# Rebuild the Regional Park station where you are standing.
execute align xz positioned ~0.5 ~ ~0.5 run function ln:put/station_regional_park
tellraw @s {"text":"Regional Park station moved here.","color":"green"}
