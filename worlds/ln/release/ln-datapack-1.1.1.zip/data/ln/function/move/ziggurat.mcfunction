# Rebuild the The Ziggurat station where you are standing.
execute align xz positioned ~0.5 ~ ~0.5 run function ln:put/station_ziggurat
tellraw @s {"text":"The Ziggurat station moved here.","color":"green"}
