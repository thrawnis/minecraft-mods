# Rebuild the City Hall & Library station where you are standing.
execute align xz positioned ~0.5 ~ ~0.5 run function ln:put/station_city_hall
tellraw @s {"text":"City Hall & Library station moved here.","color":"green"}
