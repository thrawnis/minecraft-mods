# Rebuild the Metrolink station station where you are standing.
execute align xz positioned ~0.5 ~ ~0.5 run function ln:put/station_metrolink
tellraw @s {"text":"Metrolink station station moved here.","color":"green"}
