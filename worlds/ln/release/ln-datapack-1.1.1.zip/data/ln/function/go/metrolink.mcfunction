# Teleport yourself to the Metrolink station station.
execute unless data storage ln:stations metrolink run return run tellraw @s {"text":"That station is not built yet.","color":"red"}
function ln:tp with storage ln:stations metrolink
tellraw @s {"text":"Welcome to Metrolink station!","color":"gold"}
