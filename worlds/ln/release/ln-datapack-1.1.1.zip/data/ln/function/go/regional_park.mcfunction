# Teleport yourself to the Regional Park station.
execute unless data storage ln:stations regional_park run return run tellraw @s {"text":"That station is not built yet.","color":"red"}
function ln:tp with storage ln:stations regional_park
tellraw @s {"text":"Welcome to Regional Park!","color":"gold"}
