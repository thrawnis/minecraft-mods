# Teleport yourself to the City Hall & Library station.
execute unless data storage ln:stations city_hall run return run tellraw @s {"text":"That station is not built yet.","color":"red"}
function ln:tp with storage ln:stations city_hall
tellraw @s {"text":"Welcome to City Hall & Library!","color":"gold"}
