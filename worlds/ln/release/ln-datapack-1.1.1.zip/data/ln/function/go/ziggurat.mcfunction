# Teleport yourself to the The Ziggurat station.
execute unless data storage ln:stations ziggurat run return run tellraw @s {"text":"That station is not built yet.","color":"red"}
function ln:tp with storage ln:stations ziggurat
tellraw @s {"text":"Welcome to The Ziggurat!","color":"gold"}
