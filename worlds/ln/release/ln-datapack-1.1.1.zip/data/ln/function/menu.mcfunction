dialog show @s ln:menu
