execute if score @s ln_go matches 1 run function ln:go/city_hall
execute if score @s ln_go matches 2 run function ln:go/regional_park
execute if score @s ln_go matches 3 run function ln:go/ziggurat
execute if score @s ln_go matches 4 run function ln:go/metrolink
scoreboard players set @s ln_go 0
