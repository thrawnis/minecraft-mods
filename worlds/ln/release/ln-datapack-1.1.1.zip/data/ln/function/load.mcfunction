scoreboard objectives add ln dummy
scoreboard objectives add ln_go trigger
scoreboard players set #16 ln 16
execute unless data storage ln:state {built:1b} run function ln:setup
