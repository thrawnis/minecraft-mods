# Map menu buttons set this trigger; teleport whoever pressed one.
scoreboard players enable @a ln_go
execute as @a[scores={ln_go=1..}] at @s run function ln:menu_choice
