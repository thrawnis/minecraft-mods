# Wait until every chunk is loaded, then build one item per tick.
execute unless loaded -140 0 -78 run return run schedule function ln:build 20t
execute unless loaded -158 0 -56 run return run schedule function ln:build 20t
execute unless loaded -612 0 -3682 run return run schedule function ln:build 20t
execute unless loaded -631 0 -3648 run return run schedule function ln:build 20t
execute unless loaded 139 0 -1669 run return run schedule function ln:build 20t
execute unless loaded 157 0 -1702 run return run schedule function ln:build 20t
execute unless loaded 2873 0 -4104 run return run schedule function ln:build 20t
execute unless loaded 2892 0 -4138 run return run schedule function ln:build 20t
function ln:build/0
