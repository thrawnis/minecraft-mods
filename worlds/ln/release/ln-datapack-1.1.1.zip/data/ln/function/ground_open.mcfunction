# Arnis's ground is a crust a few blocks thick with open space under it. A roof has floors
# or the ground crust somewhere in the 6-16 blocks below it, so it fails this check.
execute if block ~ ~-1 ~ #minecraft:replaceable run return fail
execute if block ~ ~-1 ~ water run return fail
execute if block ~ ~-1 ~ lava run return fail
execute unless block ~ ~-6 ~ #ln:hollow run return fail
execute unless block ~ ~-8 ~ #ln:hollow run return fail
execute unless block ~ ~-10 ~ #ln:hollow run return fail
execute unless block ~ ~-12 ~ #ln:hollow run return fail
execute unless block ~ ~-14 ~ #ln:hollow run return fail
execute unless block ~ ~-16 ~ #ln:hollow run return fail
return 1
