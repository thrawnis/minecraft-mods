tellraw @s {"text":"Finished in creative mode, so it doesn't count for the leaderboard. Switch to adventure or survival.","color":"yellow"}
