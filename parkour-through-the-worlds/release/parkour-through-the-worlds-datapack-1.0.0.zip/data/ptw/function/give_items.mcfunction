clear @s carrot_on_a_stick[custom_data={ptw:"back"}]
clear @s carrot_on_a_stick[custom_data={ptw:"restart"}]
item replace entity @s hotbar.7 with carrot_on_a_stick[custom_data={ptw:"back"},item_model="minecraft:recovery_compass",custom_name={text:"Back to checkpoint",color:"green",italic:false},unbreakable={}]
item replace entity @s hotbar.8 with carrot_on_a_stick[custom_data={ptw:"restart"},item_model="minecraft:clock",custom_name={text:"Restart course",color:"red",italic:false},unbreakable={}]
