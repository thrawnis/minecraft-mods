tag @s add ptw_self
function ptw:player_tick
tag @s remove ptw_self
