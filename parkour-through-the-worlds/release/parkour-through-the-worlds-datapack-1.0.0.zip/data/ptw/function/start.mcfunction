scoreboard players set @s ptw_run 1
scoreboard players set @s ptw_time 0
scoreboard players set @s ptw_falls 0
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 1.5
