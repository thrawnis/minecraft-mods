execute at @e[type=marker,tag=ptw_origin,limit=1] run function ptw:build_blocks
