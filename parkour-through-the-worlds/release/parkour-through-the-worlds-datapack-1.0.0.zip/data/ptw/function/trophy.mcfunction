tag @s add ptw_trophy
give @s nether_star[custom_name={text:"Parkour Champion",color:"gold",italic:false},lore=[{text:"Finished Parkour Through the Worlds",color:"gray",italic:false}],enchantment_glint_override=true]
tellraw @s {"text":"You earned the Parkour Champion trophy!","color":"gold"}
