# Run as a marker standing at the start. Saves where the course is, for restart and tracking.
execute store result storage ptw:state lx double 0.5 run data get entity @s Pos[0] 2
execute store result storage ptw:state ly double 0.5 run data get entity @s Pos[1] 2
execute store result storage ptw:state lz double 0.5 run data get entity @s Pos[2] 2
execute store result score #v ptw_c run data get entity @s Pos[1]
scoreboard players remove #v ptw_c 4
execute store result storage ptw:state lfloor int 1 run scoreboard players get #v ptw_c
# the box everyone on the course is in
execute store result score #v ptw_c run data get entity @s Pos[0]
scoreboard players remove #v ptw_c 11
execute store result storage ptw:state x1 int 1 run scoreboard players get #v ptw_c
execute store result score #v ptw_c run data get entity @s Pos[1]
scoreboard players remove #v ptw_c 47
execute store result storage ptw:state y1 int 1 run scoreboard players get #v ptw_c
execute store result score #v ptw_c run data get entity @s Pos[2]
scoreboard players remove #v ptw_c 33
execute store result storage ptw:state z1 int 1 run scoreboard players get #v ptw_c
data modify storage ptw:state dx set value 243
data modify storage ptw:state dy set value 89
data modify storage ptw:state dz set value 97
