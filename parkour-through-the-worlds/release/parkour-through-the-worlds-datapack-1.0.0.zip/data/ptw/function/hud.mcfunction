scoreboard players operation @s ptw_m = @s ptw_time
scoreboard players operation @s ptw_m /= #1200 ptw_c
scoreboard players operation @s ptw_s = @s ptw_time
scoreboard players operation @s ptw_s %= #1200 ptw_c
scoreboard players operation @s ptw_s /= #20 ptw_c
scoreboard players operation @s ptw_t = @s ptw_time
scoreboard players operation @s ptw_t %= #20 ptw_c
scoreboard players operation @s ptw_t /= #2 ptw_c
execute store result storage ptw:tmp m int 1 run scoreboard players get @s ptw_m
execute store result storage ptw:tmp s int 1 run scoreboard players get @s ptw_s
execute store result storage ptw:tmp t int 1 run scoreboard players get @s ptw_t
data modify storage ptw:tmp pad set value ""
execute if score @s ptw_s matches ..9 run data modify storage ptw:tmp pad set value "0"
function ptw:hud_show with storage ptw:tmp
