kill @e[type=marker,tag=ptw]
forceload add ~-11 ~-33 ~232 ~64
summon marker ~ ~ ~ {Tags:["ptw","ptw_origin"]}
schedule function ptw:build_go 20t
