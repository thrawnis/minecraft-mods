# Build the course at height 200 above where you stand. Run once.
execute align xz positioned ~0.5 200 ~0.5 run function ptw:build_here
