# Back to the start, timer reset.
scoreboard players set @s ptw_restart 0
scoreboard players set @s ptw_cp 0
scoreboard players set @s ptw_run 0
scoreboard players set @s ptw_time 0
scoreboard players set @s ptw_falls 0
function ptw:to_lobby with storage ptw:state
function ptw:give_items
title @s actionbar {"text":"At the start: run east to begin","color":"yellow"}
