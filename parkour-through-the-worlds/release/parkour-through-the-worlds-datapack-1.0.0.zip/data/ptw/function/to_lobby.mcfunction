$scoreboard players set @s ptw_floor $(lfloor)
$tp @s $(lx) $(ly) $(lz) -90 0
