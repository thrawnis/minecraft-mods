execute store result score @s ptw_id run data get entity @s data.id
execute store result score @s ptw_floor run data get entity @s Pos[1]
execute store result score #drop ptw_c run data get entity @s data.drop
scoreboard players operation @s ptw_floor -= #drop ptw_c
tag @s add ptw_init
