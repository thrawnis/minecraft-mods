# Everyone inside the course's box (saved at build time) is on the course.
$execute as @a[x=$(x1),y=$(y1),z=$(z1),dx=$(dx),dy=$(dy),dz=$(dz),gamemode=!spectator] at @s run function ptw:player
