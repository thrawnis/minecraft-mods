execute as @e[type=marker,tag=ptw_cp,tag=!ptw_init] run function ptw:init_marker
execute if data storage ptw:state {built:1b} run function ptw:tick_players with storage ptw:state
