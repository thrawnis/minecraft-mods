# Uses the start's saved position, which works even before that area has loaded.
$execute unless entity @s[x=$(lx),y=$(ly),z=$(lz),distance=..5.2] run function ptw:start
