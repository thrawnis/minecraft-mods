scoreboard players set @s ptw_use 0
execute if items entity @s weapon.mainhand carrot_on_a_stick[custom_data={ptw:"back"}] run function ptw:back
execute if items entity @s weapon.mainhand carrot_on_a_stick[custom_data={ptw:"restart"}] run function ptw:restart
