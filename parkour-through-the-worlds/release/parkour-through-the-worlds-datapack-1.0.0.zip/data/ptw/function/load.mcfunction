scoreboard objectives add ptw_c dummy
scoreboard players set #-1 ptw_c -1
scoreboard players set #2 ptw_c 2
scoreboard players set #20 ptw_c 20
scoreboard players set #1200 ptw_c 1200
scoreboard objectives add ptw_id dummy
scoreboard objectives add ptw_cp dummy
scoreboard objectives add ptw_floor dummy
scoreboard objectives add ptw_run dummy
scoreboard objectives add ptw_time dummy
scoreboard objectives add ptw_falls dummy
scoreboard objectives add ptw_best dummy
scoreboard objectives add ptw_y dummy
scoreboard objectives add ptw_m dummy
scoreboard objectives add ptw_s dummy
scoreboard objectives add ptw_t dummy
scoreboard objectives add ptw_board dummy {"text":"Best times","color":"gold"}
scoreboard objectives add ptw_use minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add ptw_restart trigger
scoreboard objectives add ptw_back trigger
scoreboard objectives setdisplay sidebar ptw_board
