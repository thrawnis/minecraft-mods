# as the checkpoint marker
scoreboard players operation @p[tag=ptw_self] ptw_cp = @s ptw_id
scoreboard players operation @p[tag=ptw_self] ptw_floor = @s ptw_floor
execute as @p[tag=ptw_self] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
execute if score @s ptw_id matches 1 run title @p[tag=ptw_self] subtitle {"text":"Checkpoint 1/7: next is Jungle","color":"green"}
execute if score @s ptw_id matches 2 run title @p[tag=ptw_self] subtitle {"text":"Checkpoint 2/7: next is Desert","color":"green"}
execute if score @s ptw_id matches 3 run title @p[tag=ptw_self] subtitle {"text":"Checkpoint 3/7: next is Ocean","color":"green"}
execute if score @s ptw_id matches 4 run title @p[tag=ptw_self] subtitle {"text":"Checkpoint 4/7: next is Ice","color":"green"}
execute if score @s ptw_id matches 5 run title @p[tag=ptw_self] subtitle {"text":"Checkpoint 5/7: next is Nether","color":"green"}
execute if score @s ptw_id matches 6 run title @p[tag=ptw_self] subtitle {"text":"Checkpoint 6/7: next is Deep Dark","color":"green"}
execute if score @s ptw_id matches 7 run title @p[tag=ptw_self] subtitle {"text":"Checkpoint 7/7: next is The End","color":"green"}
title @p[tag=ptw_self] title ""
