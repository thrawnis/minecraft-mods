scoreboard players set @s ptw_back 0
function ptw:to_cp
