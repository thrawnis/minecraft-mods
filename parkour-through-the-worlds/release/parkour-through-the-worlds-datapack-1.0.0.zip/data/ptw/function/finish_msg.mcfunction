title @s title {"text":"Finished!","color":"gold"}
$title @s subtitle {"text":"$(m):$(pad)$(s).$(t)","color":"yellow"}
$tellraw @a [{"selector":"@s","color":"aqua"},{"text":" finished Parkour Through the Worlds in $(m):$(pad)$(s).$(t) with ","color":"white"},{"score":{"name":"@s","objective":"ptw_falls"}},{"text":" falls!","color":"white"}]
