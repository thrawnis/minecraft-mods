# Teleport to your current checkpoint (facing the way to go).
tag @s add ptw_tp
execute as @e[type=marker,tag=ptw_cp] if score @s ptw_id = @p[tag=ptw_tp] ptw_cp run tp @p[tag=ptw_tp] @s
execute if score @s ptw_cp matches 0 run function ptw:to_lobby with storage ptw:state
tag @s remove ptw_tp
