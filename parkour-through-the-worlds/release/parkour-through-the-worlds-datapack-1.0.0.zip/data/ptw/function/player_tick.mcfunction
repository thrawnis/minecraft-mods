# Anything that teleports you ends this tick for you, so the checks below don't use
# your old position.
scoreboard players enable @s ptw_restart
scoreboard players enable @s ptw_back
execute unless score @s ptw_cp matches 0.. run return run function ptw:restart
execute if score @s ptw_restart matches 1.. run return run function ptw:restart
execute if score @s ptw_back matches 1.. run return run function ptw:back
execute if score @s ptw_use matches 1.. run return run function ptw:use_item
# reached a new checkpoint?
execute as @e[type=marker,tag=ptw_cp,tag=!ptw_lobby,tag=!ptw_finish,distance=..3] if score @s ptw_id > @p[tag=ptw_self] ptw_cp run function ptw:reach_cp
# left the start platform: start the timer
execute if score @s ptw_run matches 0 if score @s ptw_cp matches 0 run function ptw:start_check with storage ptw:state
# fell below this section: back to the checkpoint
execute store result score @s ptw_y run data get entity @s Pos[1]
execute if score @s ptw_y < @s ptw_floor run return run function ptw:fall
execute if score @s ptw_run matches 1 run scoreboard players add @s ptw_time 1
execute if score @s ptw_run matches 1 run function ptw:hud
execute if score @s ptw_run matches 1 if entity @e[type=marker,tag=ptw_finish,distance=..3.5] run function ptw:finish
