scoreboard players operation @s ptw_best = @s ptw_time
scoreboard players operation @s ptw_board = @s ptw_time
scoreboard players operation @s ptw_board *= #-1 ptw_c
$scoreboard players display numberformat @s ptw_board fixed {"text":"$(m):$(pad)$(s).$(t)","color":"yellow"}
tellraw @s {"text":"New personal best!","color":"gold","bold":true}
