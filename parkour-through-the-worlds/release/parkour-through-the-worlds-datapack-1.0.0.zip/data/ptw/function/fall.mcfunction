execute if score @s ptw_run matches 1 run scoreboard players add @s ptw_falls 1
function ptw:to_cp
playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 0.6 1
