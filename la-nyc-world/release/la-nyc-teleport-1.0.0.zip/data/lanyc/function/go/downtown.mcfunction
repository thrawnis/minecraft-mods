# Teleport the nearest player (the one who pressed the button) to Downtown LA.
execute as @p at @e[type=marker,tag=lanyc_downtown,limit=1] run tp @s ~ ~ ~1 180 0
tellraw @p {"text":"Welcome to Downtown LA!","color":"gold"}
