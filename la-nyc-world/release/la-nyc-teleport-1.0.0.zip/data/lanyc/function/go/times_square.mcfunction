# Teleport the nearest player (the one who pressed the button) to Times Square.
execute as @p at @e[type=marker,tag=lanyc_times_square,limit=1] run tp @s ~ ~ ~1 180 0
tellraw @p {"text":"Welcome to Times Square!","color":"gold"}
