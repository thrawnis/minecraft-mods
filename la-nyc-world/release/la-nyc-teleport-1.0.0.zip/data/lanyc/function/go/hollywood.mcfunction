# Teleport the nearest player (the one who pressed the button) to Hollywood.
execute as @p at @e[type=marker,tag=lanyc_hollywood,limit=1] run tp @s ~ ~ ~1 180 0
tellraw @p {"text":"Welcome to Hollywood!","color":"gold"}
