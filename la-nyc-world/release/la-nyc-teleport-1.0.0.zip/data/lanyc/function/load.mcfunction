# Build the teleport stations the first time the world loads.
execute unless data storage lanyc:state {built:1b} run function lanyc:setup
