# Wait until every station's chunk is loaded.
execute unless loaded -340 0 -185 run return run schedule function lanyc:build 20t
execute unless loaded 8194 0 4891 run return run schedule function lanyc:build 20t
execute unless loaded 4083529 0 -772936 run return run schedule function lanyc:build 20t
execute positioned -339.5 0 -184.5 positioned over motion_blocking_no_leaves run function lanyc:station/hollywood
execute positioned 8194.5 0 4891.5 positioned over motion_blocking_no_leaves run function lanyc:station/downtown
execute positioned 4083529.5 0 -772935.5 positioned over motion_blocking_no_leaves run function lanyc:station/times_square
data modify storage lanyc:state built set value 1b
tellraw @a {"text":"LA & NYC teleport stations are ready.","color":"green"}
