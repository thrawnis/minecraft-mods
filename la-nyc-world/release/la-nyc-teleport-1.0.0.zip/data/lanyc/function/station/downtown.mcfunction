# Station for Downtown LA, built at the current position (standing level).
kill @e[type=marker,tag=lanyc_downtown]
summon marker ~ ~ ~ {Tags:["lanyc","lanyc_downtown"]}
function lanyc:station/structure
