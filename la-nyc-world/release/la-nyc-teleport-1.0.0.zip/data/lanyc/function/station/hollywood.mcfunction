# Station for Hollywood, built at the current position (standing level).
kill @e[type=marker,tag=lanyc_hollywood]
summon marker ~ ~ ~ {Tags:["lanyc","lanyc_hollywood"]}
function lanyc:station/structure
