# Station for Times Square, built at the current position (standing level).
kill @e[type=marker,tag=lanyc_times_square]
summon marker ~ ~ ~ {Tags:["lanyc","lanyc_times_square"]}
function lanyc:station/structure
