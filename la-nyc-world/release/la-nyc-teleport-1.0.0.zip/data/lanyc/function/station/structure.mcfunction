# Platform with a wall and three buttons (one per area); you stand 2 blocks in front.
# Buttons are 2 apart: neighbouring command blocks would pass the signal on and all fire.
fill ~-3 ~ ~-3 ~3 ~4 ~2 air
fill ~-3 ~-1 ~-3 ~3 ~-1 ~2 smooth_stone
fill ~-3 ~ ~-2 ~3 ~2 ~-2 smooth_stone
setblock ~-3 ~2 ~-2 sea_lantern
setblock ~3 ~2 ~-2 sea_lantern
setblock ~-2 ~1 ~-2 command_block[facing=up]{Command:"function lanyc:go/hollywood"}
setblock ~-2 ~1 ~-1 stone_button[face=wall,facing=south]
setblock ~-2 ~2 ~-1 oak_wall_sign[facing=south]{front_text:{messages:["","Hollywood","",""]}}
setblock ~0 ~1 ~-2 command_block[facing=up]{Command:"function lanyc:go/downtown"}
setblock ~0 ~1 ~-1 stone_button[face=wall,facing=south]
setblock ~0 ~2 ~-1 oak_wall_sign[facing=south]{front_text:{messages:["","Downtown LA","",""]}}
setblock ~2 ~1 ~-2 command_block[facing=up]{Command:"function lanyc:go/times_square"}
setblock ~2 ~1 ~-1 stone_button[face=wall,facing=south]
setblock ~2 ~2 ~-1 oak_wall_sign[facing=south]{front_text:{messages:["","Times Square","",""]}}
