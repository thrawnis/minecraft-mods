# Keep each station's chunk loaded so teleports can find it.
forceload add -340 -185
forceload add 8194 4891
forceload add 4083529 -772936
schedule function lanyc:build 20t
