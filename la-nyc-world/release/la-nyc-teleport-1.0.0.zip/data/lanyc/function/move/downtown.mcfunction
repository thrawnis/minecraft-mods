# Rebuild the Downtown LA station where you are standing.
execute at @e[type=marker,tag=lanyc_downtown] run forceload remove ~ ~
forceload add ~ ~
execute align xz positioned ~0.5 ~ ~0.5 run function lanyc:station/downtown
tellraw @s {"text":"Downtown LA station moved here.","color":"green"}
