# Rebuild the Times Square station where you are standing.
execute at @e[type=marker,tag=lanyc_times_square] run forceload remove ~ ~
forceload add ~ ~
execute align xz positioned ~0.5 ~ ~0.5 run function lanyc:station/times_square
tellraw @s {"text":"Times Square station moved here.","color":"green"}
