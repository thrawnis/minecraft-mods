# Rebuild the Hollywood station where you are standing.
execute at @e[type=marker,tag=lanyc_hollywood] run forceload remove ~ ~
forceload add ~ ~
execute align xz positioned ~0.5 ~ ~0.5 run function lanyc:station/hollywood
tellraw @s {"text":"Hollywood station moved here.","color":"green"}
