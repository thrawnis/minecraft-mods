$execute if data storage lanyc:lamps done."$(x)_$(z)" run return 0
$execute unless loaded $(x) 0 $(z) run return 0
$data modify storage lanyc:lamps done."$(x)_$(z)" set value 1b
$execute positioned $(x) 0 $(z) run function lanyc:lamps/scan
return 1
