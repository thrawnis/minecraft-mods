execute positioned ~2 ~ ~0 positioned over motion_blocking_no_leaves unless block ~ ~-1 ~ #lanyc:asphalt run return fail
execute positioned ~6 ~ ~0 positioned over motion_blocking_no_leaves unless block ~ ~-1 ~ #lanyc:asphalt run return fail
execute positioned ~10 ~ ~0 positioned over motion_blocking_no_leaves unless block ~ ~-1 ~ #lanyc:asphalt run return fail
return 1
