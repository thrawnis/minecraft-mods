execute unless block ~ ~-1 ~ #lanyc:sidewalk run return fail
execute if block ~ ~-3 ~ #lanyc:hollow run return fail
execute if function lanyc:lamps/road_n run return run function lanyc:lamps/place
execute if function lanyc:lamps/road_s run return run function lanyc:lamps/place
execute if function lanyc:lamps/road_e run return run function lanyc:lamps/place
execute if function lanyc:lamps/road_w run return run function lanyc:lamps/place
return fail
