execute positioned ~0 ~ ~-2 positioned over motion_blocking_no_leaves unless block ~ ~-1 ~ #lanyc:asphalt run return fail
execute positioned ~0 ~ ~-6 positioned over motion_blocking_no_leaves unless block ~ ~-1 ~ #lanyc:asphalt run return fail
execute positioned ~0 ~ ~-10 positioned over motion_blocking_no_leaves unless block ~ ~-1 ~ #lanyc:asphalt run return fail
return 1
