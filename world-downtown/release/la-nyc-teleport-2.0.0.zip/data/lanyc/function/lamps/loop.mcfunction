execute as @a at @s run function lanyc:lamps/around
schedule function lanyc:lamps/loop 10t replace
