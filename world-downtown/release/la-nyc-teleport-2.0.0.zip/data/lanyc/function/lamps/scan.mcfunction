# Skip chunks that already have a lamp (Arnis's or ours).
execute positioned ~0.5 0 ~0.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~0.5 0 ~1.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~0.5 0 ~2.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~0.5 0 ~3.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~0.5 0 ~4.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~0.5 0 ~5.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~0.5 0 ~6.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~0.5 0 ~7.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~0.5 0 ~8.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~0.5 0 ~9.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~0.5 0 ~10.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~0.5 0 ~11.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~0.5 0 ~12.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~0.5 0 ~13.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~0.5 0 ~14.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~0.5 0 ~15.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~1.5 0 ~0.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~1.5 0 ~1.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~1.5 0 ~2.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~1.5 0 ~3.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~1.5 0 ~4.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~1.5 0 ~5.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~1.5 0 ~6.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~1.5 0 ~7.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~1.5 0 ~8.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~1.5 0 ~9.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~1.5 0 ~10.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~1.5 0 ~11.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~1.5 0 ~12.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~1.5 0 ~13.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~1.5 0 ~14.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~1.5 0 ~15.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~2.5 0 ~0.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~2.5 0 ~1.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~2.5 0 ~2.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~2.5 0 ~3.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~2.5 0 ~4.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~2.5 0 ~5.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~2.5 0 ~6.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~2.5 0 ~7.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~2.5 0 ~8.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~2.5 0 ~9.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~2.5 0 ~10.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~2.5 0 ~11.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~2.5 0 ~12.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~2.5 0 ~13.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~2.5 0 ~14.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~2.5 0 ~15.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~3.5 0 ~0.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~3.5 0 ~1.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~3.5 0 ~2.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~3.5 0 ~3.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~3.5 0 ~4.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~3.5 0 ~5.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~3.5 0 ~6.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~3.5 0 ~7.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~3.5 0 ~8.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~3.5 0 ~9.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~3.5 0 ~10.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~3.5 0 ~11.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~3.5 0 ~12.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~3.5 0 ~13.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~3.5 0 ~14.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~3.5 0 ~15.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~4.5 0 ~0.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~4.5 0 ~1.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~4.5 0 ~2.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~4.5 0 ~3.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~4.5 0 ~4.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~4.5 0 ~5.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~4.5 0 ~6.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~4.5 0 ~7.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~4.5 0 ~8.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~4.5 0 ~9.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~4.5 0 ~10.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~4.5 0 ~11.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~4.5 0 ~12.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~4.5 0 ~13.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~4.5 0 ~14.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~4.5 0 ~15.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~5.5 0 ~0.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~5.5 0 ~1.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~5.5 0 ~2.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~5.5 0 ~3.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~5.5 0 ~4.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~5.5 0 ~5.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~5.5 0 ~6.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~5.5 0 ~7.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~5.5 0 ~8.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~5.5 0 ~9.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~5.5 0 ~10.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~5.5 0 ~11.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~5.5 0 ~12.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~5.5 0 ~13.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~5.5 0 ~14.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~5.5 0 ~15.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~6.5 0 ~0.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~6.5 0 ~1.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~6.5 0 ~2.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~6.5 0 ~3.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~6.5 0 ~4.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~6.5 0 ~5.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~6.5 0 ~6.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~6.5 0 ~7.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~6.5 0 ~8.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~6.5 0 ~9.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~6.5 0 ~10.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~6.5 0 ~11.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~6.5 0 ~12.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~6.5 0 ~13.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~6.5 0 ~14.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~6.5 0 ~15.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~7.5 0 ~0.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~7.5 0 ~1.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~7.5 0 ~2.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~7.5 0 ~3.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~7.5 0 ~4.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~7.5 0 ~5.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~7.5 0 ~6.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~7.5 0 ~7.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~7.5 0 ~8.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~7.5 0 ~9.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~7.5 0 ~10.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~7.5 0 ~11.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~7.5 0 ~12.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~7.5 0 ~13.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~7.5 0 ~14.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~7.5 0 ~15.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~8.5 0 ~0.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~8.5 0 ~1.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~8.5 0 ~2.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~8.5 0 ~3.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~8.5 0 ~4.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~8.5 0 ~5.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~8.5 0 ~6.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~8.5 0 ~7.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~8.5 0 ~8.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~8.5 0 ~9.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~8.5 0 ~10.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~8.5 0 ~11.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~8.5 0 ~12.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~8.5 0 ~13.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~8.5 0 ~14.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~8.5 0 ~15.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~9.5 0 ~0.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~9.5 0 ~1.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~9.5 0 ~2.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~9.5 0 ~3.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~9.5 0 ~4.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~9.5 0 ~5.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~9.5 0 ~6.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~9.5 0 ~7.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~9.5 0 ~8.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~9.5 0 ~9.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~9.5 0 ~10.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~9.5 0 ~11.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~9.5 0 ~12.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~9.5 0 ~13.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~9.5 0 ~14.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~9.5 0 ~15.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~10.5 0 ~0.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~10.5 0 ~1.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~10.5 0 ~2.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~10.5 0 ~3.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~10.5 0 ~4.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~10.5 0 ~5.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~10.5 0 ~6.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~10.5 0 ~7.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~10.5 0 ~8.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~10.5 0 ~9.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~10.5 0 ~10.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~10.5 0 ~11.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~10.5 0 ~12.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~10.5 0 ~13.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~10.5 0 ~14.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~10.5 0 ~15.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~11.5 0 ~0.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~11.5 0 ~1.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~11.5 0 ~2.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~11.5 0 ~3.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~11.5 0 ~4.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~11.5 0 ~5.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~11.5 0 ~6.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~11.5 0 ~7.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~11.5 0 ~8.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~11.5 0 ~9.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~11.5 0 ~10.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~11.5 0 ~11.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~11.5 0 ~12.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~11.5 0 ~13.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~11.5 0 ~14.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~11.5 0 ~15.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~12.5 0 ~0.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~12.5 0 ~1.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~12.5 0 ~2.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~12.5 0 ~3.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~12.5 0 ~4.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~12.5 0 ~5.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~12.5 0 ~6.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~12.5 0 ~7.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~12.5 0 ~8.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~12.5 0 ~9.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~12.5 0 ~10.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~12.5 0 ~11.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~12.5 0 ~12.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~12.5 0 ~13.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~12.5 0 ~14.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~12.5 0 ~15.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~13.5 0 ~0.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~13.5 0 ~1.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~13.5 0 ~2.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~13.5 0 ~3.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~13.5 0 ~4.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~13.5 0 ~5.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~13.5 0 ~6.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~13.5 0 ~7.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~13.5 0 ~8.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~13.5 0 ~9.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~13.5 0 ~10.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~13.5 0 ~11.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~13.5 0 ~12.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~13.5 0 ~13.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~13.5 0 ~14.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~13.5 0 ~15.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~14.5 0 ~0.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~14.5 0 ~1.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~14.5 0 ~2.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~14.5 0 ~3.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~14.5 0 ~4.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~14.5 0 ~5.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~14.5 0 ~6.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~14.5 0 ~7.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~14.5 0 ~8.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~14.5 0 ~9.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~14.5 0 ~10.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~14.5 0 ~11.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~14.5 0 ~12.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~14.5 0 ~13.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~14.5 0 ~14.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~14.5 0 ~15.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~15.5 0 ~0.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~15.5 0 ~1.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~15.5 0 ~2.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~15.5 0 ~3.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~15.5 0 ~4.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~15.5 0 ~5.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~15.5 0 ~6.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~15.5 0 ~7.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~15.5 0 ~8.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~15.5 0 ~9.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~15.5 0 ~10.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~15.5 0 ~11.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~15.5 0 ~12.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~15.5 0 ~13.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~15.5 0 ~14.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
execute positioned ~15.5 0 ~15.5 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ #lanyc:lamp_top run return 0
# Put one lamp on the first sidewalk beside a main road.
execute positioned ~0.5 0 ~0.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~0.5 0 ~1.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~0.5 0 ~2.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~0.5 0 ~3.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~0.5 0 ~4.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~0.5 0 ~5.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~0.5 0 ~6.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~0.5 0 ~7.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~0.5 0 ~8.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~0.5 0 ~9.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~0.5 0 ~10.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~0.5 0 ~11.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~0.5 0 ~12.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~0.5 0 ~13.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~0.5 0 ~14.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~0.5 0 ~15.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~1.5 0 ~0.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~1.5 0 ~1.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~1.5 0 ~2.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~1.5 0 ~3.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~1.5 0 ~4.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~1.5 0 ~5.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~1.5 0 ~6.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~1.5 0 ~7.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~1.5 0 ~8.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~1.5 0 ~9.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~1.5 0 ~10.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~1.5 0 ~11.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~1.5 0 ~12.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~1.5 0 ~13.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~1.5 0 ~14.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~1.5 0 ~15.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~2.5 0 ~0.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~2.5 0 ~1.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~2.5 0 ~2.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~2.5 0 ~3.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~2.5 0 ~4.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~2.5 0 ~5.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~2.5 0 ~6.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~2.5 0 ~7.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~2.5 0 ~8.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~2.5 0 ~9.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~2.5 0 ~10.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~2.5 0 ~11.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~2.5 0 ~12.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~2.5 0 ~13.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~2.5 0 ~14.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~2.5 0 ~15.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~3.5 0 ~0.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~3.5 0 ~1.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~3.5 0 ~2.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~3.5 0 ~3.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~3.5 0 ~4.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~3.5 0 ~5.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~3.5 0 ~6.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~3.5 0 ~7.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~3.5 0 ~8.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~3.5 0 ~9.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~3.5 0 ~10.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~3.5 0 ~11.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~3.5 0 ~12.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~3.5 0 ~13.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~3.5 0 ~14.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~3.5 0 ~15.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~4.5 0 ~0.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~4.5 0 ~1.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~4.5 0 ~2.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~4.5 0 ~3.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~4.5 0 ~4.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~4.5 0 ~5.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~4.5 0 ~6.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~4.5 0 ~7.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~4.5 0 ~8.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~4.5 0 ~9.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~4.5 0 ~10.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~4.5 0 ~11.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~4.5 0 ~12.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~4.5 0 ~13.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~4.5 0 ~14.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~4.5 0 ~15.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~5.5 0 ~0.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~5.5 0 ~1.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~5.5 0 ~2.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~5.5 0 ~3.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~5.5 0 ~4.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~5.5 0 ~5.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~5.5 0 ~6.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~5.5 0 ~7.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~5.5 0 ~8.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~5.5 0 ~9.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~5.5 0 ~10.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~5.5 0 ~11.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~5.5 0 ~12.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~5.5 0 ~13.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~5.5 0 ~14.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~5.5 0 ~15.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~6.5 0 ~0.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~6.5 0 ~1.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~6.5 0 ~2.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~6.5 0 ~3.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~6.5 0 ~4.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~6.5 0 ~5.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~6.5 0 ~6.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~6.5 0 ~7.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~6.5 0 ~8.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~6.5 0 ~9.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~6.5 0 ~10.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~6.5 0 ~11.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~6.5 0 ~12.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~6.5 0 ~13.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~6.5 0 ~14.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~6.5 0 ~15.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~7.5 0 ~0.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~7.5 0 ~1.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~7.5 0 ~2.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~7.5 0 ~3.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~7.5 0 ~4.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~7.5 0 ~5.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~7.5 0 ~6.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~7.5 0 ~7.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~7.5 0 ~8.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~7.5 0 ~9.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~7.5 0 ~10.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~7.5 0 ~11.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~7.5 0 ~12.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~7.5 0 ~13.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~7.5 0 ~14.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~7.5 0 ~15.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~8.5 0 ~0.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~8.5 0 ~1.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~8.5 0 ~2.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~8.5 0 ~3.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~8.5 0 ~4.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~8.5 0 ~5.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~8.5 0 ~6.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~8.5 0 ~7.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~8.5 0 ~8.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~8.5 0 ~9.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~8.5 0 ~10.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~8.5 0 ~11.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~8.5 0 ~12.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~8.5 0 ~13.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~8.5 0 ~14.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~8.5 0 ~15.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~9.5 0 ~0.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~9.5 0 ~1.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~9.5 0 ~2.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~9.5 0 ~3.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~9.5 0 ~4.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~9.5 0 ~5.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~9.5 0 ~6.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~9.5 0 ~7.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~9.5 0 ~8.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~9.5 0 ~9.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~9.5 0 ~10.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~9.5 0 ~11.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~9.5 0 ~12.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~9.5 0 ~13.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~9.5 0 ~14.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~9.5 0 ~15.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~10.5 0 ~0.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~10.5 0 ~1.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~10.5 0 ~2.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~10.5 0 ~3.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~10.5 0 ~4.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~10.5 0 ~5.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~10.5 0 ~6.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~10.5 0 ~7.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~10.5 0 ~8.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~10.5 0 ~9.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~10.5 0 ~10.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~10.5 0 ~11.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~10.5 0 ~12.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~10.5 0 ~13.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~10.5 0 ~14.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~10.5 0 ~15.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~11.5 0 ~0.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~11.5 0 ~1.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~11.5 0 ~2.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~11.5 0 ~3.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~11.5 0 ~4.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~11.5 0 ~5.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~11.5 0 ~6.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~11.5 0 ~7.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~11.5 0 ~8.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~11.5 0 ~9.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~11.5 0 ~10.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~11.5 0 ~11.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~11.5 0 ~12.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~11.5 0 ~13.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~11.5 0 ~14.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~11.5 0 ~15.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~12.5 0 ~0.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~12.5 0 ~1.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~12.5 0 ~2.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~12.5 0 ~3.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~12.5 0 ~4.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~12.5 0 ~5.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~12.5 0 ~6.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~12.5 0 ~7.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~12.5 0 ~8.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~12.5 0 ~9.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~12.5 0 ~10.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~12.5 0 ~11.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~12.5 0 ~12.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~12.5 0 ~13.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~12.5 0 ~14.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~12.5 0 ~15.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~13.5 0 ~0.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~13.5 0 ~1.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~13.5 0 ~2.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~13.5 0 ~3.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~13.5 0 ~4.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~13.5 0 ~5.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~13.5 0 ~6.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~13.5 0 ~7.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~13.5 0 ~8.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~13.5 0 ~9.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~13.5 0 ~10.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~13.5 0 ~11.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~13.5 0 ~12.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~13.5 0 ~13.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~13.5 0 ~14.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~13.5 0 ~15.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~14.5 0 ~0.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~14.5 0 ~1.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~14.5 0 ~2.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~14.5 0 ~3.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~14.5 0 ~4.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~14.5 0 ~5.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~14.5 0 ~6.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~14.5 0 ~7.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~14.5 0 ~8.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~14.5 0 ~9.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~14.5 0 ~10.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~14.5 0 ~11.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~14.5 0 ~12.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~14.5 0 ~13.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~14.5 0 ~14.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~14.5 0 ~15.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~15.5 0 ~0.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~15.5 0 ~1.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~15.5 0 ~2.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~15.5 0 ~3.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~15.5 0 ~4.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~15.5 0 ~5.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~15.5 0 ~6.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~15.5 0 ~7.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~15.5 0 ~8.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~15.5 0 ~9.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~15.5 0 ~10.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~15.5 0 ~11.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~15.5 0 ~12.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~15.5 0 ~13.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~15.5 0 ~14.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
execute positioned ~15.5 0 ~15.5 positioned over motion_blocking_no_leaves if function lanyc:lamps/try run return 1
