# Lamp post that switches on at night (inverted daylight sensor on top).
setblock ~ ~ ~ smooth_stone
fill ~ ~1 ~ ~ ~3 ~ stone_brick_wall
setblock ~ ~4 ~ redstone_lamp
setblock ~ ~5 ~ daylight_detector[inverted=true]
return 1
