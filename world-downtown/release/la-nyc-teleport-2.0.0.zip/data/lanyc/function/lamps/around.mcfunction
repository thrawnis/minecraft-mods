# Check the chunks around this player; give a few new ones lamps.
scoreboard players set #done lanyc 0
execute store result score #cx lanyc run data get entity @s Pos[0]
execute store result score #cz lanyc run data get entity @s Pos[2]
scoreboard players operation #cx lanyc /= #16 lanyc
scoreboard players operation #cz lanyc /= #16 lanyc
execute if score #done lanyc matches 2.. run return 0
scoreboard players operation #x lanyc = #cx lanyc
scoreboard players add #x lanyc 0
scoreboard players operation #x lanyc *= #16 lanyc
scoreboard players operation #z lanyc = #cz lanyc
scoreboard players add #z lanyc 0
scoreboard players operation #z lanyc *= #16 lanyc
execute store result storage lanyc:tmp x int 1 run scoreboard players get #x lanyc
execute store result storage lanyc:tmp z int 1 run scoreboard players get #z lanyc
execute store result score #r lanyc run function lanyc:lamps/chunk with storage lanyc:tmp
scoreboard players operation #done lanyc += #r lanyc
execute if score #done lanyc matches 2.. run return 0
scoreboard players operation #x lanyc = #cx lanyc
scoreboard players remove #x lanyc 1
scoreboard players operation #x lanyc *= #16 lanyc
scoreboard players operation #z lanyc = #cz lanyc
scoreboard players add #z lanyc 0
scoreboard players operation #z lanyc *= #16 lanyc
execute store result storage lanyc:tmp x int 1 run scoreboard players get #x lanyc
execute store result storage lanyc:tmp z int 1 run scoreboard players get #z lanyc
execute store result score #r lanyc run function lanyc:lamps/chunk with storage lanyc:tmp
scoreboard players operation #done lanyc += #r lanyc
execute if score #done lanyc matches 2.. run return 0
scoreboard players operation #x lanyc = #cx lanyc
scoreboard players add #x lanyc 0
scoreboard players operation #x lanyc *= #16 lanyc
scoreboard players operation #z lanyc = #cz lanyc
scoreboard players remove #z lanyc 1
scoreboard players operation #z lanyc *= #16 lanyc
execute store result storage lanyc:tmp x int 1 run scoreboard players get #x lanyc
execute store result storage lanyc:tmp z int 1 run scoreboard players get #z lanyc
execute store result score #r lanyc run function lanyc:lamps/chunk with storage lanyc:tmp
scoreboard players operation #done lanyc += #r lanyc
execute if score #done lanyc matches 2.. run return 0
scoreboard players operation #x lanyc = #cx lanyc
scoreboard players add #x lanyc 0
scoreboard players operation #x lanyc *= #16 lanyc
scoreboard players operation #z lanyc = #cz lanyc
scoreboard players add #z lanyc 1
scoreboard players operation #z lanyc *= #16 lanyc
execute store result storage lanyc:tmp x int 1 run scoreboard players get #x lanyc
execute store result storage lanyc:tmp z int 1 run scoreboard players get #z lanyc
execute store result score #r lanyc run function lanyc:lamps/chunk with storage lanyc:tmp
scoreboard players operation #done lanyc += #r lanyc
execute if score #done lanyc matches 2.. run return 0
scoreboard players operation #x lanyc = #cx lanyc
scoreboard players add #x lanyc 1
scoreboard players operation #x lanyc *= #16 lanyc
scoreboard players operation #z lanyc = #cz lanyc
scoreboard players add #z lanyc 0
scoreboard players operation #z lanyc *= #16 lanyc
execute store result storage lanyc:tmp x int 1 run scoreboard players get #x lanyc
execute store result storage lanyc:tmp z int 1 run scoreboard players get #z lanyc
execute store result score #r lanyc run function lanyc:lamps/chunk with storage lanyc:tmp
scoreboard players operation #done lanyc += #r lanyc
execute if score #done lanyc matches 2.. run return 0
scoreboard players operation #x lanyc = #cx lanyc
scoreboard players remove #x lanyc 1
scoreboard players operation #x lanyc *= #16 lanyc
scoreboard players operation #z lanyc = #cz lanyc
scoreboard players remove #z lanyc 1
scoreboard players operation #z lanyc *= #16 lanyc
execute store result storage lanyc:tmp x int 1 run scoreboard players get #x lanyc
execute store result storage lanyc:tmp z int 1 run scoreboard players get #z lanyc
execute store result score #r lanyc run function lanyc:lamps/chunk with storage lanyc:tmp
scoreboard players operation #done lanyc += #r lanyc
execute if score #done lanyc matches 2.. run return 0
scoreboard players operation #x lanyc = #cx lanyc
scoreboard players remove #x lanyc 1
scoreboard players operation #x lanyc *= #16 lanyc
scoreboard players operation #z lanyc = #cz lanyc
scoreboard players add #z lanyc 1
scoreboard players operation #z lanyc *= #16 lanyc
execute store result storage lanyc:tmp x int 1 run scoreboard players get #x lanyc
execute store result storage lanyc:tmp z int 1 run scoreboard players get #z lanyc
execute store result score #r lanyc run function lanyc:lamps/chunk with storage lanyc:tmp
scoreboard players operation #done lanyc += #r lanyc
execute if score #done lanyc matches 2.. run return 0
scoreboard players operation #x lanyc = #cx lanyc
scoreboard players add #x lanyc 1
scoreboard players operation #x lanyc *= #16 lanyc
scoreboard players operation #z lanyc = #cz lanyc
scoreboard players remove #z lanyc 1
scoreboard players operation #z lanyc *= #16 lanyc
execute store result storage lanyc:tmp x int 1 run scoreboard players get #x lanyc
execute store result storage lanyc:tmp z int 1 run scoreboard players get #z lanyc
execute store result score #r lanyc run function lanyc:lamps/chunk with storage lanyc:tmp
scoreboard players operation #done lanyc += #r lanyc
execute if score #done lanyc matches 2.. run return 0
scoreboard players operation #x lanyc = #cx lanyc
scoreboard players add #x lanyc 1
scoreboard players operation #x lanyc *= #16 lanyc
scoreboard players operation #z lanyc = #cz lanyc
scoreboard players add #z lanyc 1
scoreboard players operation #z lanyc *= #16 lanyc
execute store result storage lanyc:tmp x int 1 run scoreboard players get #x lanyc
execute store result storage lanyc:tmp z int 1 run scoreboard players get #z lanyc
execute store result score #r lanyc run function lanyc:lamps/chunk with storage lanyc:tmp
scoreboard players operation #done lanyc += #r lanyc
execute if score #done lanyc matches 2.. run return 0
scoreboard players operation #x lanyc = #cx lanyc
scoreboard players remove #x lanyc 2
scoreboard players operation #x lanyc *= #16 lanyc
scoreboard players operation #z lanyc = #cz lanyc
scoreboard players add #z lanyc 0
scoreboard players operation #z lanyc *= #16 lanyc
execute store result storage lanyc:tmp x int 1 run scoreboard players get #x lanyc
execute store result storage lanyc:tmp z int 1 run scoreboard players get #z lanyc
execute store result score #r lanyc run function lanyc:lamps/chunk with storage lanyc:tmp
scoreboard players operation #done lanyc += #r lanyc
execute if score #done lanyc matches 2.. run return 0
scoreboard players operation #x lanyc = #cx lanyc
scoreboard players add #x lanyc 0
scoreboard players operation #x lanyc *= #16 lanyc
scoreboard players operation #z lanyc = #cz lanyc
scoreboard players remove #z lanyc 2
scoreboard players operation #z lanyc *= #16 lanyc
execute store result storage lanyc:tmp x int 1 run scoreboard players get #x lanyc
execute store result storage lanyc:tmp z int 1 run scoreboard players get #z lanyc
execute store result score #r lanyc run function lanyc:lamps/chunk with storage lanyc:tmp
scoreboard players operation #done lanyc += #r lanyc
execute if score #done lanyc matches 2.. run return 0
scoreboard players operation #x lanyc = #cx lanyc
scoreboard players add #x lanyc 0
scoreboard players operation #x lanyc *= #16 lanyc
scoreboard players operation #z lanyc = #cz lanyc
scoreboard players add #z lanyc 2
scoreboard players operation #z lanyc *= #16 lanyc
execute store result storage lanyc:tmp x int 1 run scoreboard players get #x lanyc
execute store result storage lanyc:tmp z int 1 run scoreboard players get #z lanyc
execute store result score #r lanyc run function lanyc:lamps/chunk with storage lanyc:tmp
scoreboard players operation #done lanyc += #r lanyc
execute if score #done lanyc matches 2.. run return 0
scoreboard players operation #x lanyc = #cx lanyc
scoreboard players add #x lanyc 2
scoreboard players operation #x lanyc *= #16 lanyc
scoreboard players operation #z lanyc = #cz lanyc
scoreboard players add #z lanyc 0
scoreboard players operation #z lanyc *= #16 lanyc
execute store result storage lanyc:tmp x int 1 run scoreboard players get #x lanyc
execute store result storage lanyc:tmp z int 1 run scoreboard players get #z lanyc
execute store result score #r lanyc run function lanyc:lamps/chunk with storage lanyc:tmp
scoreboard players operation #done lanyc += #r lanyc
