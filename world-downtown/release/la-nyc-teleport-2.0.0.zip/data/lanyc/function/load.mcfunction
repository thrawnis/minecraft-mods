scoreboard objectives add lanyc dummy
scoreboard objectives add lanyc_go trigger
scoreboard players set #16 lanyc 16
execute unless data storage lanyc:state {built:1b} run function lanyc:setup
schedule function lanyc:lamps/loop 10t replace
